/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { NavPage, SystemKPIs, PumpData, AlertItem } from './types';
import { initialKPIs, initialPumps, initialAlertLogs } from './data/mockData';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { OverviewView } from './components/OverviewView';
import { WaterQualityView } from './components/WaterQualityView';
import { RiverMonitoringView } from './components/RiverMonitoringView';
import { PumpMonitoringView } from './components/PumpMonitoringView';
import { AnomalyDetectionView } from './components/AnomalyDetectionView';
import { ForecastView } from './components/ForecastView';
import { AlertLogView } from './components/AlertLogView';

export default function App() {
  const [currentPage, setCurrentPage] = useState<NavPage>('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [kpis, setKpis] = useState<SystemKPIs>(initialKPIs);
  const [pumps, setPumps] = useState<PumpData[]>(initialPumps);
  const [alerts, setAlerts] = useState<AlertItem[]>(initialAlertLogs);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Active alert count calculation
  const activeAlertCount = alerts.filter((a) => a.status === 'open').length;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Simulate refreshing data from plant telemetry
  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      const now = new Date();
      const timeStr = now.toLocaleDateString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      }) + ' GMT+7';

      setKpis((prev) => ({
        ...prev,
        currentEc: parseFloat((243.5 + (Math.random() - 0.5) * 1.5).toFixed(3)),
        currentPh: parseFloat((7.24 + (Math.random() - 0.5) * 0.04).toFixed(3)),
        currentTurbidity: parseFloat((1.27 + (Math.random() - 0.5) * 0.05).toFixed(3)),
        currentCl2: parseFloat((0.53 + (Math.random() - 0.5) * 0.02).toFixed(3)),
        currentRiverLevel: parseFloat((2.17 + (Math.random() - 0.5) * 0.03).toFixed(3)),
        qnt: parseFloat((801.95 + (Math.random() - 0.5) * 4).toFixed(3)),
        lastUpdated: timeStr
      }));

      setIsRefreshing(false);
      showToast('Đã đồng bộ dữ liệu viễn trắc thành công.');
    }, 600);
  };

  // Alert actions
  const handleAcknowledgeAlert = (id: string, operatorName: string) => {
    const now = new Date().toISOString();
    setAlerts((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              status: 'acknowledged',
              acknowledged_at: now,
              acknowledged_by: operatorName
            }
          : item
      )
    );
    showToast(`Cảnh báo [${id}] đã được tiếp nhận bởi ${operatorName}`);
  };

  const handleResolveAlert = (id: string) => {
    setAlerts((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: 'resolved' } : item))
    );
    showToast(`Đã đánh dấu xử lý hoàn tất cảnh báo [${id}]`);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 tech-grid">
      {/* Sidebar navigation */}
      <Sidebar
        currentPage={currentPage}
        onSelectPage={setCurrentPage}
        activeAlertCount={activeAlertCount}
        onRefresh={handleRefresh}
        isRefreshing={isRefreshing}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main View Area */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-slate-950/90">
        {/* Universal Top Header */}
        <Header
          currentPage={currentPage}
          kpis={kpis}
          onRefresh={handleRefresh}
          isRefreshing={isRefreshing}
          onOpenAlerts={() => setCurrentPage('alert_log')}
        />

        {/* Scrollable View Content */}
        <main className="flex-1 overflow-y-auto px-6 py-5">
          <div className="max-w-7xl mx-auto">
            {currentPage === 'overview' && (
              <OverviewView
                kpis={kpis}
                pumps={pumps}
                onNavigate={setCurrentPage}
              />
            )}

            {currentPage === 'water_quality' && <WaterQualityView />}

            {currentPage === 'river_monitoring' && <RiverMonitoringView />}

            {currentPage === 'pump_monitoring' && <PumpMonitoringView pumps={pumps} />}

            {currentPage === 'anomaly_detection' && <AnomalyDetectionView />}

            {currentPage === 'forecast' && <ForecastView />}

            {currentPage === 'alert_log' && (
              <AlertLogView
                alerts={alerts}
                onAcknowledgeAlert={handleAcknowledgeAlert}
                onResolveAlert={handleResolveAlert}
              />
            )}
          </div>
        </main>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2 px-4 py-2.5 rounded-lg bg-slate-900 border border-cyan-500/40 text-cyan-300 text-xs font-mono shadow-xl shadow-cyan-950/40 animate-fade-in">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
